# Teapot: Status Codes

[![latest_stable_version_img]][latest_stable_version]
[![latest_unstable_version_img]][latest_unstable_version]
[![license_img]][license]
[![twitter_img]][twitter]

Part of the teapot library. This is a port of all of the status codes, so the exceptions etc don't get included in this one.

[latest_stable_version_img]: https://img.shields.io/packagist/v/teapot/status-code.svg "Latest Stable Version"
[latest_stable_version]: https://packagist.org/packages/teapot/status-code "Latest Stable Version"

[latest_unstable_version_img]: https://img.shields.io/packagist/vpre/teapot/status-code.svg "Latest Unstable Version"
[latest_unstable_version]: https://packagist.org/packages/teapot/status-code "Latest Unstable Version"

[license_img]: https://img.shields.io/packagist/l/teapot/status-code.svg "License"
[license]: https://packagist.org/packages/teapot/status-code

[twitter_img]: https://img.shields.io/badge/twitter-%40shrikeh-blue.svg "@shrikeh on Twitter"
[twitter]: https://twitter.com/shrikeh

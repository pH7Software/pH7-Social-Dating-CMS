<?php
/**
 * Created by Florian Pradines
 */

namespace Skeerel\Exception;

class APIException extends \Exception {}
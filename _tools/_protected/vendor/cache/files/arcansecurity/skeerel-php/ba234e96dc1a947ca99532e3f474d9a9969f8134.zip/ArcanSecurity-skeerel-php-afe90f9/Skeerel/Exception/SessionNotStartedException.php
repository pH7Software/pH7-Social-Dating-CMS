<?php
/**
 * Created by Florian Pradines
 */

namespace Skeerel\Exception;

class SessionNotStartedException extends \Exception {}
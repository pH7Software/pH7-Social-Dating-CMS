<?php
/**
 * Created by Florian Pradines
 */

namespace Skeerel\Exception;

class PaymentException extends \Exception {}
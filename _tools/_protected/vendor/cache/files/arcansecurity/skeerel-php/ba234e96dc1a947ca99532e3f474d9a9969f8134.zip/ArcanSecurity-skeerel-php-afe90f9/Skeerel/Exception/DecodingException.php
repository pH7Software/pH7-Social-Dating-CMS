<?php
/**
 * Created by Florian Pradines
 */

namespace Skeerel\Exception;

class DecodingException extends \Exception {}
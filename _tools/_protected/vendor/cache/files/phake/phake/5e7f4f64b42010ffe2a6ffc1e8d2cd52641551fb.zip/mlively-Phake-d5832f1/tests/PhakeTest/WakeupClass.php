<?php

class PhakeTest_WakeupClass
{
    public function __wakeup()
    {
        // do something fun
    }
}

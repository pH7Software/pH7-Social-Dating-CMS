.. Phake - PHP Mocking Framework documentation master file, created by
   sphinx-quickstart on Wed Apr  2 02:02:12 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Phake - PHP Mocking Framework's documentation!
=========================================================

.. toctree::
   :maxdepth: 2

   introduction
   getting-started
   mocks
   method-stubbing
   method-verification
   mocking-statics
   answers
   method-parameter-matchers
   configuration

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


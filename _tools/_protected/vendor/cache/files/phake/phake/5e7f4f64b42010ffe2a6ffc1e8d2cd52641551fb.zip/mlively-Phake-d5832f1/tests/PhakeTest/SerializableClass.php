<?php


class PhakeTest_SerializableClass implements \Serializable
{
    public function serialize()
    {

    }

    public function unserialize($serialized)
    {

    }

} 
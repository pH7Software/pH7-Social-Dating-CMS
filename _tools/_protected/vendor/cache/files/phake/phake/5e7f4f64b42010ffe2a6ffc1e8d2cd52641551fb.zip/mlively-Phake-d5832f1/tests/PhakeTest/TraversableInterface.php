<?php

interface PhakeTest_TraversableInterface extends Traversable
{

}

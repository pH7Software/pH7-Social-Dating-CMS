<?php
class PhakeTest_ToStringMethod
{
    public function __toString()
    {

    }
}

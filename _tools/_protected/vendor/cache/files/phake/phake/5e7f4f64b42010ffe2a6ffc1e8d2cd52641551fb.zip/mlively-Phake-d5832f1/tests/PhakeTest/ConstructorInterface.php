<?php

interface PhakeTest_ConstructorInterface
{
    public function __construct(PhakeTest_A $a);
}

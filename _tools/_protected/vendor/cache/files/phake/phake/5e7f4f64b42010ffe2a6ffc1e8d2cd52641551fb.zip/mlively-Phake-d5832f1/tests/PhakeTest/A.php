<?php

/**
 * @author Mike Lively <mike.lively@sellingsource.com>
 */
class PhakeTest_A
{

}

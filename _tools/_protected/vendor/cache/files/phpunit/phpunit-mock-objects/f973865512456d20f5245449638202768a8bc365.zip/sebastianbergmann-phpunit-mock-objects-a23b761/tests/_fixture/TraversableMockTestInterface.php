<?php
interface TraversableMockTestInterface extends Traversable
{
}
